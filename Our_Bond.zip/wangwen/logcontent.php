<DOCTYPE html>
    <html>
        <head>
            <meta charset="UTF-8"/>
            <link rel="stylesheet" type="text/css" href="homepage.css" />
        </head>
        <body>
            <div id="head">
            <table class="header">
                <tr id="pic_logo">
                    <td rowspan="2">
                        <img src="logo_1.jpg" width= 80/>
                    </td>
                    <td class="login">
                        <a href="login.html">Sign in</a>
                    </td>
                </tr>
                
                <tr>
                    <td class="login">
                        <a href="register.html">Private Page</a>
                    </td>
                </tr>
                
            </table>
        </div>
        </body>
    </html>
    
    