<?php
header("Location: wangwen/main.php");
?>