<?php
require('../bz/output_fns.php');
?>