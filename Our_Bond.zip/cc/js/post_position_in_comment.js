var source;
source = document.getElementById("post");
source.style.position = "absolute";
source.style.left = -130;
source.style.top = 150;