<?php
define("HOST", "kanro.db.9140140.hostedresource.com");
define("USER", "kanro");
define("PASS", "666666");
define("DB_NAME", "ourbond");
?>