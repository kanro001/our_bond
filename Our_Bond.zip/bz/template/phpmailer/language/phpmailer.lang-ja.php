<?php
/**
* PHPMailer language file: refer to English translation for definitive list
* Japanese Version
* By Mitsuhiro Yoshida - http://mitstek.com/
*/

$PHPMAILER_LANG['authenticate'] = 'SMTP銈ㄣ儵銉� 瑾嶈銇с亶銇俱仜銈撱仹銇椼仧銆';
$PHPMAILER_LANG['connect_host'] = 'SMTP銈ㄣ儵銉� SMTP銉涖偣銉堛伀鎺ョ稓銇с亶銇俱仜銈撱仹銇椼仧銆';
$PHPMAILER_LANG['data_not_accepted'] = 'SMTP銈ㄣ儵銉� 銉囥兗銈裤亴鍙椼亼浠樸亼銈夈倢銇俱仜銈撱仹銇椼仧銆';
//$PHPMAILER_LANG['empty_message']        = 'Message body empty';
$PHPMAILER_LANG['encoding'] = '涓嶆槑銇偍銉炽偝銉笺儑銈ｃ兂銈';
$PHPMAILER_LANG['execute'] = '瀹熻銇с亶銇俱仜銈撱仹銇椼仧: ';
$PHPMAILER_LANG['file_access'] = '銉曘偂銈ゃ儷銇偄銈偦銈广仹銇嶃伨銇涖倱: ';
$PHPMAILER_LANG['file_open'] = '銉曘偂銈ゃ儷銈ㄣ儵銉� 銉曘偂銈ゃ儷銈掗枊銇戙伨銇涖倱: ';
$PHPMAILER_LANG['from_failed'] = '娆°伄From銈儔銉偣銇枔閬曘亜銇屻亗銈娿伨銇� ';
$PHPMAILER_LANG['instantiate'] = '銉°兗銉枹鏁般亴姝ｅ父銇嫊浣溿仐銇俱仜銈撱仹銇椼仧銆';
//$PHPMAILER_LANG['invalid_email']        = 'Not sending, email address is invalid: ';
$PHPMAILER_LANG['provide_address'] = '灏戙仾銇忋仺銈�銇ゃ儭銉笺儷銈儔銉偣銈�鎸囧畾銇欍倠蹇呰銇屻亗銈娿伨銇欍�';
$PHPMAILER_LANG['mailer_not_supported'] = ' 銉°兗銉┿兗銇屻偟銉濄兗銉堛仌銈屻仸銇勩伨銇涖倱銆';
$PHPMAILER_LANG['recipients_failed'] = 'SMTP銈ㄣ儵銉� 娆°伄鍙椾俊鑰呫偄銉夈儸銈广伀 闁撻仌銇勩亴銇傘倞銇俱仚: ';
//$PHPMAILER_LANG['signing']              = 'Signing Error: ';
//$PHPMAILER_LANG['smtp_connect_failed']  = 'SMTP Connect() failed.';
//$PHPMAILER_LANG['smtp_error']           = 'SMTP server error: ';
//$PHPMAILER_LANG['variable_set']         = 'Cannot set or reset variable: ';
?>