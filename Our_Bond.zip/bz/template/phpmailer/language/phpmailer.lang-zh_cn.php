<?php
/**
* PHPMailer language file: refer to English translation for definitive list
* Simplified Chinese Version
* @author liqwei <liqwei@liqwei.com>
*/

$PHPMAILER_LANG['authenticate'] = 'SMTP 閿欒锛氱櫥褰曞け璐ャ�';
$PHPMAILER_LANG['connect_host'] = 'SMTP 閿欒锛氭棤娉曡繛鎺ュ埌 SMTP 涓绘満銆';
$PHPMAILER_LANG['data_not_accepted'] = 'SMTP 閿欒锛氭暟鎹笉琚帴鍙椼�';
//$P$PHPMAILER_LANG['empty_message']        = 'Message body empty';
$PHPMAILER_LANG['encoding'] = '鏈煡缂栫爜: ';
$PHPMAILER_LANG['execute'] = '鏃犳硶鎵ц锛';
$PHPMAILER_LANG['file_access'] = '鏃犳硶璁块棶鏂囦欢锛';
$PHPMAILER_LANG['file_open'] = '鏂囦欢閿欒锛氭棤娉曟墦寮�枃浠讹細';
$PHPMAILER_LANG['from_failed'] = '鍙戦�鍦板潃閿欒锛';
$PHPMAILER_LANG['instantiate'] = '鏈煡鍑芥暟璋冪敤銆';
//$PHPMAILER_LANG['invalid_email']        = 'Not sending, email address is invalid: ';
$PHPMAILER_LANG['mailer_not_supported'] = '鍙戜俊瀹㈡埛绔笉琚敮鎸併�';
$PHPMAILER_LANG['provide_address'] = '蹇呴』鎻愪緵鑷冲皯涓�釜鏀朵欢浜哄湴鍧��';
$PHPMAILER_LANG['recipients_failed'] = 'SMTP 閿欒锛氭敹浠朵汉鍦板潃閿欒锛';
//$PHPMAILER_LANG['signing']              = 'Signing Error: ';
//$PHPMAILER_LANG['smtp_connect_failed']  = 'SMTP Connect() failed.';
//$PHPMAILER_LANG['smtp_error']           = 'SMTP server error: ';
//$PHPMAILER_LANG['variable_set']         = 'Cannot set or reset variable: ';
?>