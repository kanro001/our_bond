<?php
/**
* PHPMailer language file: refer to English translation for definitive list
* Traditional Chinese Version
* @author liqwei <liqwei@liqwei.com>
*/

$PHPMAILER_LANG['authenticate'] = 'SMTP 閷锛氱櫥閷勫け鏁椼�';
$PHPMAILER_LANG['connect_host'] = 'SMTP 閷锛氱劇娉曢�鎺ュ埌 SMTP 涓绘銆';
$PHPMAILER_LANG['data_not_accepted'] = 'SMTP 閷锛氭暩鎿氫笉琚帴鍙椼�';
//$PHPMAILER_LANG['empty_message']        = 'Message body empty';
$PHPMAILER_LANG['encoding'] = '鏈煡绶ㄧ⒓: ';
$PHPMAILER_LANG['file_access'] = '鐒℃硶瑷晱鏂囦欢锛';
$PHPMAILER_LANG['file_open'] = '鏂囦欢閷锛氱劇娉曟墦闁嬫枃浠讹細';
$PHPMAILER_LANG['from_failed'] = '鐧奸�鍦板潃閷锛';
$PHPMAILER_LANG['execute'] = '鐒℃硶鍩疯锛';
$PHPMAILER_LANG['instantiate'] = '鏈煡鍑芥暩瑾跨敤銆';
//$PHPMAILER_LANG['invalid_email']        = 'Not sending, email address is invalid: ';
$PHPMAILER_LANG['provide_address'] = '蹇呴爤鎻愪緵鑷冲皯涓��鏀朵欢浜哄湴鍧��';
$PHPMAILER_LANG['mailer_not_supported'] = '鐧间俊瀹㈡埗绔笉琚敮鎸併�';
$PHPMAILER_LANG['recipients_failed'] = 'SMTP 閷锛氭敹浠朵汉鍦板潃閷锛';
//$PHPMAILER_LANG['signing']              = 'Signing Error: ';
//$PHPMAILER_LANG['smtp_connect_failed']  = 'SMTP Connect() failed.';
//$PHPMAILER_LANG['smtp_error']           = 'SMTP server error: ';
//$PHPMAILER_LANG['variable_set']         = 'Cannot set or reset variable: ';
?>