<?php
/**
* PHPMailer language file: refer to English translation for definitive list
* Chinese Version
* By LiuXin: www.80x86.cn/blog/
*/

$PHPMAILER_LANG['authenticate'] = 'SMTP 閿欒锛氳韩浠介獙璇佸け璐ャ�';
$PHPMAILER_LANG['connect_host'] = 'SMTP 閿欒: 涓嶈兘杩炴帴SMTP涓绘満銆';
$PHPMAILER_LANG['data_not_accepted'] = 'SMTP 閿欒: 鏁版嵁涓嶅彲鎺ュ彈銆';
//$PHPMAILER_LANG['empty_message']        = 'Message body empty';
$PHPMAILER_LANG['encoding'] = '鏈煡缂栫爜锛';
$PHPMAILER_LANG['execute'] = '涓嶈兘鎵ц: ';
$PHPMAILER_LANG['file_access'] = '涓嶈兘璁块棶鏂囦欢锛';
$PHPMAILER_LANG['file_open'] = '鏂囦欢閿欒锛氫笉鑳芥墦寮�枃浠讹細';
$PHPMAILER_LANG['from_failed'] = '涓嬮潰鐨勫彂閫佸湴鍧�偖浠跺彂閫佸け璐ヤ簡锛�';
$PHPMAILER_LANG['instantiate'] = '涓嶈兘瀹炵幇mail鏂规硶銆';
//$PHPMAILER_LANG['invalid_email']        = 'Not sending, email address is invalid: ';
$PHPMAILER_LANG['mailer_not_supported'] = ' 鎮ㄦ墍閫夋嫨鐨勫彂閫侀偖浠剁殑鏂规硶骞朵笉鏀寔銆';
$PHPMAILER_LANG['provide_address'] = '鎮ㄥ繀椤绘彁渚涜嚦灏戜竴涓�鏀朵俊浜虹殑email鍦板潃銆';
$PHPMAILER_LANG['recipients_failed'] = 'SMTP 閿欒锛�涓嬮潰鐨�鏀朵欢浜哄け璐ヤ簡锛�';
//$PHPMAILER_LANG['signing']              = 'Signing Error: ';
//$PHPMAILER_LANG['smtp_connect_failed']  = 'SMTP Connect() failed.';
//$PHPMAILER_LANG['smtp_error']           = 'SMTP server error: ';
//$PHPMAILER_LANG['variable_set']         = 'Cannot set or reset variable: ';
?>